import random


class RandomPolicy:

    def __init__(self, size):
        self.size = size
        self.cache = []
        self.name = 'rr'

    def access(self, current):

        if current in self.cache:
            return True
        else:
            if len(self.cache) > self.size:
                assert False
            elif len(self.cache) == self.size:  # full
                self.cache.remove(random.sample(self.cache, 1)[0])

            self.cache = [current] + self.cache

            return False


class FifoPolicy:

    def __init__(self, size):
        self.size = size
        self.cache = list()
        self.name = 'fifo'

    def access(self, current):

        if current in self.cache:
            return True
        else:

            if len(self.cache) > self.size:
                assert False
            elif len(self.cache) == self.size:  # full
                self.cache = self.cache[:-1]

            self.cache = [current] + self.cache

            return False


def run_test(trace, pol):
    hit = []
    for i in range(len(trace)):
        # update cache
        hit += [pol.access(trace[i])]

    return sum(hit) / len(hit)


if __name__ == '__main__':
    # parameters
    caps = [1, 2, 3, 4, 5]

    # load trace from file
    traces = []
    for name in ['trace1.txt', 'trace2.txt']:
        with open(name) as f:
            traces += [list(eval(f.read()))]

    # run strategy over trace
    for i in range(len(traces)):
        for cap in caps:
            for pol in [FifoPolicy(size=cap), RandomPolicy(size=cap)]:
                print(f'data={i},\tcap={cap},\tname={pol.name},\thitrate={run_test(traces[i], pol)}')
